
  # Wecycle Circular Economy Platform

  This is a code bundle for Wecycle Circular Economy Platform. The original project is available at https://www.figma.com/design/50zdYHPBJw4P5nEFRpq0ef/Wecycle-Circular-Economy-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  